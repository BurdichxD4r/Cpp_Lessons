#include "MyWidget.h"

MyWidget::MyWidget(QWidget *parent) : QWidget(parent)
{
    m_plblToolTip = new QLCDNumber;
    m_plblToolTip->setWindowFlags(Qt::ToolTip);
}
