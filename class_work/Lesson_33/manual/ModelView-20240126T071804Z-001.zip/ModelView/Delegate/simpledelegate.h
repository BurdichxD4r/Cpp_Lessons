#ifndef SIMPLEDELEGATE_H
#define SIMPLEDELEGATE_H

#include <QWidget>

class SimpleDelegate : public QWidget
{
    Q_OBJECT

public:
    SimpleDelegate(QWidget *parent = nullptr);
    ~SimpleDelegate();
};
#endif // SIMPLEDELEGATE_H
