#include "simpledelegate.h"

SimpleDelegate::SimpleDelegate(QWidget *parent)
    : QWidget(parent)
{
}

SimpleDelegate::~SimpleDelegate()
{
}

