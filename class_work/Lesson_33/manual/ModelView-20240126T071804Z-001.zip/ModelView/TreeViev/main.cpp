#include "widget.h"
#include <QFileSystemModel>
#include <QApplication>
#include <QTreeView>
#include <QTableView>
#include <QObject>
#include <QSplitter>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    QFileSystemModel model;
    QSplitter   spl(Qt::Horizontal);
    QTreeView * pTreeView = new QTreeView;
    model.setRootPath(QDir::rootPath());
    pTreeView->setModel(&model);
    QTableView * pTableView = new QTableView;
    pTableView->setModel(&model);

    QObject::connect(pTreeView, &QTreeView::clicked, pTableView, &QTableView::setRootIndex);
    QObject::connect(pTableView, & QTableView::activated, pTreeView, &QTreeView::setCurrentIndex);
    QObject::connect(pTableView, &QTableView::activated, pTableView, &QTableView::setRootIndex);
    spl.addWidget(pTreeView);
    spl.addWidget(pTableView);
    spl.show();
    return a.exec();
}
