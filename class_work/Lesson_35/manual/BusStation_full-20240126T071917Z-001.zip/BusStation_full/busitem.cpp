#include "busitem.h"

BusItem::BusItem(QString fio, QString route, QString bus):
    m_fio(fio), m_route(route), m_bus(bus)
{

}
