#include "dialogbusitem.h"
#include "ui_dialogbusitem.h"

DialogBusItem::DialogBusItem(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogBusItem)
{
    ui->setupUi(this);
}

DialogBusItem::~DialogBusItem()
{
    delete ui;
}
QString DialogBusItem::routNum()const{
    return ui->leNumRoute->text();
}
QString DialogBusItem::busNum() const{
    return ui->le_NumBus->text();
}
QString DialogBusItem::fio() const{
    return ui->leF->text() +" "+ui->leI->text()+" "+ ui->leO->text();
}
