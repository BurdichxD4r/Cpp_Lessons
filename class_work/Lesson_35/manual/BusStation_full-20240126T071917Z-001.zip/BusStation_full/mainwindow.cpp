#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>
#include "dialogbusitem.h"
//------------------------------------------------
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    // создание таблиц для списков автобусов на маршруте и в автопарке с
    // необходимыми настройками
    createTable(ui->tw_list_into);
    createTable(ui->tw_list_out);

    // пока таблицы пусты эти пункты меню следует отключить
    ui->act_item_in->setEnabled(false);
    ui->act_item_out->setEnabled(false);

}
//-----------------------------------------------
MainWindow::~MainWindow()
{
    delete ui;
}
//-----------------------------------------------
void MainWindow::on_act_about_triggered()
{
    QMessageBox::about(0, "О программе", "Программа Автобусный парк Вер. 1.0");
}
//-----------------------------------------------

void MainWindow::on_act_new_triggered()
{
    ui->tw_list_into->setEditTriggers(QTableWidget::NoEditTriggers);

    DialogBusItem* pinputDialog = new DialogBusItem();// создание диалог. окна для ввода данных об автобусе

    if (pinputDialog->exec() == QDialog::Accepted){ // вызов диалог .окна

        QMessageBox::information(0,"Информация",  // после закрытия диал. окна данные из него помещаем в
                             "ФИО водителя: "     // сообщение для оператора
                             + pinputDialog->fio()
                             + "\nНомер автобуса: "
                             + pinputDialog->busNum()
                             + "\nНомер маршрута: "
                             + pinputDialog->routNum()
                             ) ;

    BusItem *bus = new BusItem(pinputDialog->fio(),    // с новыми введенными данными создаем экземпляр класса
                               pinputDialog->routNum(),
                               pinputDialog->busNum());
    m_list_bus_into.append(bus); // помещаем экземпляр в вектор(список автобусов в парке)
    addToTable(bus, ui->tw_list_into); // добавляем новую запись в табл.
     }

    delete pinputDialog;   // освобожнение переменной выделенной для диалога
}
//------------------------------------------------
void MainWindow::createTable(QTableWidget * tbl){

    // создание и настройка таблиц
    tbl->horizontalHeader()->setStretchLastSection(true);
    tbl->resizeColumnsToContents();
    tbl->setColumnCount(3); // задействуем 3 колонки

    QStringList headers; // формирование заголовка табл.
        headers.append("№ маршрута");
        headers.append("№ автобуса");
        headers.append("ФИО водителя");
    tbl->setHorizontalHeaderLabels(headers); // установление заголовка в табл.
    tbl->setSelectionBehavior(QAbstractItemView::SelectRows);// поведение таблицы при выделении строки пользователем
    tbl->setEditTriggers(QTableWidget::NoEditTriggers); // возможность редактирования табл.(пока отключаем)
}
//------------------------------------------------
void MainWindow::addToTable(BusItem *bus, QTableWidget *tbl)
{
    // добавление нового элемента в табл.
    int n = tbl->rowCount(); // выясняем сколько строк сейчас в талб
    tbl->setRowCount(n+1);  // увеличиваем число строк на 1
    // помещаем данные об автобусе в табл.
    tbl->setItem(n,0, new QTableWidgetItem(bus->getRoute()));
    tbl->setItem(n,1, new QTableWidgetItem(bus->getBus()));
    tbl->setItem(n,2, new QTableWidgetItem(bus->getFio()));
}
//--------------------------------------------------

void MainWindow::on_act_edit_triggered()
{
    // изменяем возможность редактирования табл.
    ui->tw_list_into->setEditTriggers(QTableWidget::AllEditTriggers);
}
//---------------------------------------------------

void MainWindow::on_act_exit_triggered()
{
    // закрытие формы
    close();
}
//---------------------------------------------------

void MainWindow::on_act_item_out_triggered()
{
// перенос элемента из табл. в автопарке в табл. на маршруте
 int cur = ui->tw_list_into->currentRow();
 BusItem * bus_out = m_list_bus_into.at(cur);
 m_list_bus_into.remove(cur);
 m_list_bus_out.append(bus_out);
 addToTable(bus_out, ui->tw_list_out);
 ui->tw_list_into->removeRow(cur);

 ui->act_item_in->setEnabled(false);
 ui->act_item_out->setEnabled(false);
}


void MainWindow::on_act_item_in_triggered()
{
   // перенос элемента из табл. на маршруте в табл. в автопарке
    int cur = ui->tw_list_out->currentRow();
    BusItem * bus_in = m_list_bus_out.at(cur);
    m_list_bus_out.remove(cur);
    m_list_bus_into.append(bus_in);
    addToTable(bus_in, ui->tw_list_into);
    ui->tw_list_out->removeRow(cur);

    // управление поведением меню
    ui->act_item_in->setEnabled(false);
    ui->act_item_out->setEnabled(false);
}


void MainWindow::on_tw_list_into_cellClicked(int row, int column)
{
    // управление поведением меню
    if(row>-1)
        ui->act_item_out->setEnabled(true);
}


void MainWindow::on_tw_list_out_cellClicked(int row, int column)
{
    // управление поведением меню
    if(row>-1)
        ui->act_item_in->setEnabled(true);
}

void MainWindow::findItem(const QString &findSampl, QVector<BusItem*> &list )
{
    QVector<BusItem*> ::iterator it = list.begin();
    for (; it!=list.end();++it){
        if((*it)->getRoute() == findSampl){
            QMessageBox::information(0,"Результат поиска",  // после закрытия диал. окна данные из него помещаем в
                                 "ФИО водителя: "     // сообщение для оператора
                                 + (*it)->getFio()
                                 + "\nНомер автобуса: "
                                 + (*it)->getBus()
                                 + "\nНомер маршрута: "
                                 + (*it)->getRoute()
                                 ) ;
        }
    }
}

void MainWindow::on_bt_find_in_clicked()
{
    QString routNum = ui->leFind_in->text(); // образец для поиска
    findItem(routNum, m_list_bus_into);

}


void MainWindow::on_bt_find_out_clicked()
{
    QString routNum = ui->leFind_out->text(); // образец для поиска
    findItem(routNum, m_list_bus_out);
}

