#ifndef DIALOGBUSITEM_H
#define DIALOGBUSITEM_H

#include <QDialog>

namespace Ui {
class DialogBusItem;
}

class DialogBusItem : public QDialog
{
    Q_OBJECT

public:
    explicit DialogBusItem(QWidget *parent = nullptr);
    ~DialogBusItem();

    // методы для получения данных из диалогового окна
 QString routNum()const;
 QString busNum() const;
 QString fio() const;

private:
    Ui::DialogBusItem *ui;
};

#endif // DIALOGBUSITEM_H
