#ifndef BUSITEM_H
#define BUSITEM_H
#include <QString>
// класс автобуса автопарка
class BusItem
{
private:
    // параметры записи автобуса в системе автопарка
    QString m_fio{""};  // фио водителя
    QString m_route{""}; // номер маршрута
    QString m_bus{""};   // номер автобуса
public:
    BusItem(QString fio="", QString route="", QString bus="");
    QString getFio(){return m_fio;};
    QString getRoute(){return m_route;};
    QString getBus(){return m_bus;};

    void setFio(QString fio){m_fio = fio;};
    void setRoute(QString route){m_route= route;};
    void setBus(QString bus){m_bus= bus;};
};

#endif // BUSITEM_H
