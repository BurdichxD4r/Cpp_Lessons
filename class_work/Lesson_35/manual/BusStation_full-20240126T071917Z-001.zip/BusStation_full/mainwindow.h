#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QVector>
#include <QTableWidget>
#include "busitem.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    // слоты меню
    void on_act_about_triggered();
    void on_act_new_triggered();
    void on_act_edit_triggered();
    void on_act_exit_triggered();
    void on_act_item_out_triggered();
    void on_act_item_in_triggered();
    // слоты таблиц
    void on_tw_list_into_cellClicked(int row, int column);
    void on_tw_list_out_cellClicked(int row, int column);

    void on_bt_find_in_clicked();

    void on_bt_find_out_clicked();

private:
    Ui::MainWindow *ui;

    QVector<BusItem*> m_list_bus_into; // список автобусов в автопаке
    QVector<BusItem*> m_list_bus_out;  // список автобусов на маршруте

    void addToTable(BusItem *bus, QTableWidget *tbl); // метод добавления записи об автобусе в одну из таблиц
    void createTable(QTableWidget * tbl); // метод создания одной из таблиц
    void findItem(const QString & findSampl, QVector<BusItem*> &list ); // функция поиска рейса по номеру
};
#endif // MAINWINDOW_H
