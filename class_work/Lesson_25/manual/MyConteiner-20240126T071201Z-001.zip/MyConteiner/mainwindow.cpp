#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QRegularExpressionValidator>
#include <QRegularExpression>
#include <QSignalMapper>


//-----------------------------------------------------
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    ValidatorInUse();
    VectorInUse();
    MapperInUse();
}
//-------------------------------------------------------
MainWindow::~MainWindow()
{
    delete ui;
}
//---------------------------------------------------------
void MainWindow::ValidatorInUse()
{
    QRegularExpressionValidator * regValid[3];

    QRegularExpression regExp01_89("0[1-9]|[1-8][0-9]");       // допустимые значения 01-89
    regValid[0]= new QRegularExpressionValidator(regExp01_89, this);

    QRegularExpression regExp01_03_13("0[1-3]|1[3]");  // допустимые значения 01-03,13
    regValid[1]= new QRegularExpressionValidator(regExp01_03_13, this);

    QRegularExpression regExp02_16("0[2-9]|1[0-6]");    // допустимые значения 02-16
    regValid[2]= new QRegularExpressionValidator(regExp02_16, this);


         ui->le_0->setValidator(regValid[0]);
         ui->le_0->setInputMask("00");
         ui->le_0->setText("02");
         ui->le_0->setCursorPosition(0);

         ui->le_1->setValidator(regValid[1]);
         ui->le_1->setInputMask("00");
         ui->le_1->setText("01");
         ui->le_1->setCursorPosition(0);

         ui->le_2->setValidator(regValid[2]);
         ui->le_2->setInputMask("00");
         ui->le_2->setText("02");
         ui->le_2->setCursorPosition(0);

}
//-------------------------------------------------------------------
void MainWindow::VectorInUse(){

    m_vec_but.push_back(ui->pb_1);
    m_vec_but.push_back(ui->pb_2);
    m_vec_but.push_back(ui->pb_3);
    m_vec_but.push_back(ui->pb_4);
    m_vec_but.push_back(ui->pb_5);
    m_vec_but.push_back(ui->pb_6);

}
//-------------------------------------------------------------------
void MainWindow::slotAdd(int num)
{
    int n = ui->lcdNumber->value();
    ui->lcdNumber->display(n+num);
}
//-------------------------------------------------------------------
void MainWindow::slotSub(int num)
{
   int n = ui->lcdNumber->value();
    ui->lcdNumber->display(n - num);
}
//-------------------------------------------------------------------
void MainWindow::MapperInUse()
{

    //переопределение сигналов  с пом класса QSignalMapper для сокращения кол-ва слотов методов
    QSignalMapper *pSigMapAdd = new QSignalMapper(this);
    connect (pSigMapAdd, SIGNAL(mapped(int)), this, SLOT(slotAdd(int)));

    QSignalMapper *pSigMapSub = new QSignalMapper(this);
    connect (pSigMapSub, SIGNAL(mapped(int)), this, SLOT(slotSub(int)));


    for(int i = 0; i < m_vec_but.count(); ++i) {

        if(i%2){ // четные  sub
          connect (m_vec_but[i], SIGNAL(clicked()), pSigMapSub, SLOT(map()));
          int num = 1;
          pSigMapSub->setMapping(m_vec_but[i],num);
        }
        else{ // нечет add
            connect (m_vec_but[i], SIGNAL(clicked()), pSigMapAdd, SLOT(map()));
            int num = 1;
            pSigMapAdd->setMapping(m_vec_but[i],num);
        }

     }
}

//----------------------------------------------------------------------

