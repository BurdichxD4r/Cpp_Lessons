#include "MyThread.h"
#include <QLCDNumber>
#include <QProgressBar>
#include "MyThread.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    QLCDNumber lcd;
    QLCDNumber lcd_2;
    QProgressBar prb;
    QProgressBar prb_2;

    MyThread thread_1;
    MyThread thread_2;
    MyThread thread_3;
    MyThread thread_4;

    QObject::connect(&thread_1, SIGNAL(currentValue(int)), &lcd, SLOT(display(int)));
    QObject::connect(&thread_4, SIGNAL(currentValue(int)), &lcd_2, SLOT(display(int)));

    QObject::connect(&thread_2, SIGNAL(currentValue(int)), &prb,    SLOT(setValue(int)));
    QObject::connect(&thread_3, SIGNAL(currentValue(int)), &prb_2,    SLOT(setValue(int)));

    QObject::connect(&thread_2, SIGNAL(finished()), &a,    SLOT(quit()));

     lcd.setSegmentStyle(QLCDNumber::Filled);
     lcd.display(100);
     lcd.resize(220, 90);
     lcd.show();

     lcd_2.setSegmentStyle(QLCDNumber::Filled);
     lcd_2.display(100);
     lcd_2.resize(220, 90);
     lcd_2.show();

     prb.show();
     prb.setValue(100);

     prb_2.show();
     prb_2.setValue(100);

     thread_1.start();
     thread_2.start();
     thread_3.start();
     thread_4.start();

    return a.exec();
}
