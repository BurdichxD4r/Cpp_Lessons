#include "MyThread.h"
//-------------------------------------
MyThread::MyThread() : m_nValue(100)
    {
    }
//-----------------------------------
void MyThread::run()
 {
   QTimer timer;
   connect(&timer, SIGNAL(timeout()), SLOT(slotNextValue()));
   timer.start(100);

   exec();
 }
//-----------------------------------
void MyThread::slotNextValue()
{

    emit currentValue(--m_nValue);

    if (!m_nValue) {
        emit finished();
    }
}
//------------------------------------
