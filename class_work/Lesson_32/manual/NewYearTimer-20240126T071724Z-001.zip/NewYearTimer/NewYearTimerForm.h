#ifndef NEWYEARTIMERFORM_H
#define NEWYEARTIMERFORM_H

#include <QWidget>
#include "ui_NewYearTimerForm.h"
class NewYearTimerForm : public QWidget
{
    Q_OBJECT
private:
    Ui::NewYeayTimer m_ui;
public:
    NewYearTimerForm(QWidget *parent = nullptr);
    ~NewYearTimerForm();
    void displayDateTime();
};
#endif // NEWYEARTIMERFORM_H
