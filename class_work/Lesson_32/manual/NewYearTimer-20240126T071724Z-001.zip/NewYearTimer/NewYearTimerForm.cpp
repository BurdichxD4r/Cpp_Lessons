#include "NewYearTimerForm.h"
#include <QDate>
NewYearTimerForm::NewYearTimerForm(QWidget *parent)
    : QWidget(parent)
{
     m_ui.setupUi(this);
     displayDateTime();
}
//-----------------------------------
NewYearTimerForm::~NewYearTimerForm()
{

}
//------------------------------------
void NewYearTimerForm::displayDateTime()
{
    QDate today = QDate::currentDate();
    m_ui.lb_now->setText(today.toString("yyyy.MMM.ddd"));
    QDate dateNewYear(today.year(),12, 31);
    int NYday =  today.daysTo(dateNewYear);
    m_ui.lcd_d->display(NYday);
}
