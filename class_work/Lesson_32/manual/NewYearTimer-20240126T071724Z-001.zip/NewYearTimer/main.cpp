#include "NewYearTimerForm.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    NewYearTimerForm form;
    form.show();
    return a.exec();
}
