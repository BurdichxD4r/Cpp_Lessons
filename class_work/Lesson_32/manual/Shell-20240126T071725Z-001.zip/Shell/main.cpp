#include "shell.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Shell shell;
    shell.show();
    return a.exec();
}
