#include "shell.h"
//#include <QTextC>
#

Shell::Shell(QWidget *parent)
    : QWidget(parent)
{
    m_process = new QProcess(this);
    m_ptxtDisplay = new QTextEdit;
    QLabel *plbl = new QLabel ("&Command:");
#ifdef Q_OS_WIN
        QString strCommand = "dir";
#else
         QString strCommand ="ls";
#endif

         m_ptxtCommand = new QLineEdit(strCommand);
         plbl->setBuddy(m_ptxtCommand);
         QPushButton * pcmd = new QPushButton("&Enter");
         connect(m_process,
                         &QProcess::readyReadStandardError/*readyReadStandardOutput*/, this,// (readyReadStandardOutput()),
                         &Shell::slotDataOnStdout);

         connect(m_ptxtCommand,
                         &QLineEdit::returnPressed, this,
                         &Shell::slotReturnPressed);
         connect(pcmd, &QPushButton::clicked, this, &Shell::slotReturnPressed);

                 //Layout setup
                 QHBoxLayout* phbxLayout = new QHBoxLayout;
                 phbxLayout->addWidget(plbl);
                 phbxLayout->addWidget(m_ptxtCommand);
                 phbxLayout->addWidget(pcmd);

                 QVBoxLayout* pvbxLayout = new QVBoxLayout;
                 pvbxLayout->addWidget(m_ptxtDisplay);
                 pvbxLayout->addLayout(phbxLayout);
                 setLayout(pvbxLayout);
}
//--------------------------------------------------------------
Shell::~Shell()
{
    // http://programming-lang.com/ru/comp_programming/blanshet/0/j148.html
}
//----------------------------------------------------------------
void Shell::slotDataOnStdout(){
    //QTextCodec *codec = QTextCodec::codecForName("IBM 866");
   //         ui->textEdit->append( codec->toUnicode(m_process->readAllStandardOutput() ) );
     m_ptxtDisplay->append(m_process->readAllStandardOutput());
}
//------------------------------------------------------------------
void Shell::slotReturnPressed(){
    QString strCommand = "";
    #ifdef Q_WS_WIN64
            strCommand = "cmd /C ";
    #endif
            strCommand += m_ptxtCommand->text();
            m_process->start(strCommand);//"C:\\Windows\\System32\\cmd.exe",QStringList() << "/K" << "dir c:\\");

}
//---------------------------------------------------------------------
