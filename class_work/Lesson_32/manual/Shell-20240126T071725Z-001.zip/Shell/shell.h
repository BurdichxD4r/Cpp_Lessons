#ifndef SHELL_H
#define SHELL_H
#include <QProcess>
#include <QtWidgets>
#include <QWidget>

class Shell : public QWidget
{
    Q_OBJECT
private:
    QProcess *m_process;
    QLineEdit * m_ptxtCommand;
    QTextEdit * m_ptxtDisplay;

public:
    Shell(QWidget *parent = nullptr);
    ~Shell();
public slots:
void slotDataOnStdout();
void slotReturnPressed();
};
#endif // SHELL_H
