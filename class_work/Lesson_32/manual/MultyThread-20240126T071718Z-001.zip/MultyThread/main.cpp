#include <QCoreApplication>
#include "simplethread.h"

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

        SimpleThread threadA("thread A");
        SimpleThread threadB("thread B");
        SimpleThread threadC("thread C");

        threadA.start();    // Запускаем потоки
        threadB.start();    // и наблюдаем их параллельную работу
        threadC.start();    // в выводе qDebug

        return a.exec();

    return a.exec();
}
