#ifndef SIMPLETHREAD_H
#define SIMPLETHREAD_H
#include <QThread>

class SimpleThread :public QThread
{
private:
    QString name;   // Имя потока
public:
    explicit SimpleThread(QString threadName);
     void run();
};

#endif // SIMPLETHREAD_H
