#include "simplethread.h"
#include <QDebug>

SimpleThread::SimpleThread(QString threadName): name(threadName)
{

}
void SimpleThread::run()
{
    for (int i = 0; i <= 1000; i++ ) {
        qDebug() << name << " " << i;
    }
}
