#include "mainwindow.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    //MainWindow w1(1);
    MainWindow w1;
    QStringList headers;
    headers << "Subject: Hello Qt"
            << "From: BaturinaYlena.com";
    QString body = "Проверка.\r\n";
    Message message(body, headers);
    w1.setMessage(message);

    //MainWindow w2(2);
    MainWindow w2;

   // QObject::connect(&w1, &MainWindow::messageSent, &w2, &MainWindow::setMessage);
   // QObject::connect(&w2, &MainWindow::messageSent, &w1, &MainWindow::setMessage);

    QObject::connect(&w1, SIGNAL(messageSent(const Message &)), &w2, SLOT(setMessage(const Message &)));
    QObject::connect(&w2, SIGNAL(messageSent(const Message &)), &w1, SLOT(setMessage(const Message &)));

    w1.show();
    w2.show();

    return a.exec();
}
