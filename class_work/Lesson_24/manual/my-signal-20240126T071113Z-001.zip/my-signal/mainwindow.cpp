#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(/*int id,*/QWidget *parent) :
  /* m_id_wind(id),*/ QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
   // this->setWindowTitle("Окно "+QString::number(m_id_wind));
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::setMessage(const Message &message)
{
    m_thisMessage = message;
    ui->textEdit->setPlainText(m_thisMessage.body());
}

void MainWindow::on_pushButton_clicked()
{
    m_thisMessage = Message(ui->textEdit->toPlainText(), m_thisMessage.headers());
    emit messageSent(m_thisMessage);

}
