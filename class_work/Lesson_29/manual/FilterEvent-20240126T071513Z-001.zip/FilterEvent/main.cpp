#include "widget.h"
#include <QtWidgets>
#include <QApplication>
#include "mousefilter.h"

int main(int argc, char *argv[]){
    QApplication a(argc, argv);

    QLineEdit le_txt("QLineEdit");
    le_txt.installEventFilter(new MouseFilter(&le_txt));
    le_txt.show();

    QLabel lbl("QLabel");
    lbl.installEventFilter(new MouseFilter(&lbl));
    lbl.show();

    QPushButton pb_1("QPushButton");
    pb_1.installEventFilter(new MouseFilter(&pb_1));
    pb_1.show();


   // Widget w;
   // w.show();
    return a.exec();
}
